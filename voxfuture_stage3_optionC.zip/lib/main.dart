
import 'package:flutter/material.dart';
import 'theme/app_theme.dart';
import 'screens/splash/splash_screen.dart';
import 'screens/welcome/welcome_screen.dart';

void main()=>runApp(const VoxApp());

class VoxApp extends StatelessWidget{
  const VoxApp({super.key});
  @override
  Widget build(BuildContext context){
    return MaterialApp(
      theme: AppTheme.dark,
      initialRoute: SplashScreen.routeName,
      routes:{
        SplashScreen.routeName:(_)=>const SplashScreen(),
        WelcomeScreen.routeName:(_)=>const WelcomeScreen(),
      },
    );
  }
}
