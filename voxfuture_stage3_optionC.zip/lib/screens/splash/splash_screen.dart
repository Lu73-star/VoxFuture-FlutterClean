
import 'dart:async';
import 'package:flutter/material.dart';
import '../../theme/app_theme.dart';
import '../welcome/welcome_screen.dart';

class SplashScreen extends StatefulWidget {
  static const routeName = '/';
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Timer(const Duration(seconds: 2), () {
      if (mounted) {
        Navigator.pushReplacementNamed(context, WelcomeScreen.routeName);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Positioned.fill(
            child: Image.asset('assets/images/bg_scifi.png', fit: BoxFit.cover),
          ),
          Center(
            child: Image.asset('assets/images/logo.png', width: 220),
          ),
        ],
      ),
    );
  }
}
