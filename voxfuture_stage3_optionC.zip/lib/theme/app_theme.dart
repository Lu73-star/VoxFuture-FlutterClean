
import 'package:flutter/material.dart';

class AppColors {
  static const background = Color(0xFF050712);
  static const primary = Color(0xFFF3A622);
}
class AppTheme {
  static ThemeData get dark => ThemeData.dark().copyWith(
    primaryColor: AppColors.primary,
  );
}
