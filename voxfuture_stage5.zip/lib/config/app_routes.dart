class AppRoutes{}
