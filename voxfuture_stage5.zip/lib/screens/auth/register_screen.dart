import 'package:flutter/material.dart';
class RegisterScreen extends StatelessWidget{
 static const routeName='/register';
 const RegisterScreen({super.key});
 @override Widget build(c)=>Scaffold(body:Center(child:Text('Register')));
}
