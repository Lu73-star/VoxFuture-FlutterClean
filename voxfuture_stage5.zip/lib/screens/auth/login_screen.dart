import 'package:flutter/material.dart';
class LoginScreen extends StatelessWidget{
 static const routeName='/login';
 const LoginScreen({super.key});
 @override Widget build(c)=>Scaffold(body:Center(child:Text('Login')));
}
