import 'package:flutter/material.dart';
class SplashScreen extends StatelessWidget{
 static const routeName='/';
 const SplashScreen({super.key});
 @override Widget build(c)=>Scaffold(body:Center(child:Text('Splash Ultra Sci-Fi')));
}
