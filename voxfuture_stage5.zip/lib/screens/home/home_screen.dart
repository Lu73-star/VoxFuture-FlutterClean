import 'package:flutter/material.dart';
class HomeScreen extends StatelessWidget{
 static const routeName='/home';
 const HomeScreen({super.key});
 @override Widget build(c)=>Scaffold(body:Center(child:Text('Dashboard Ultra Sci-Fi')));
}
