import 'package:flutter/material.dart';
class NewPredictionScreen extends StatelessWidget{
 static const routeName='/new_prediction';
 const NewPredictionScreen({super.key});
 @override Widget build(c)=>Scaffold(body:Center(child:Text('Nova Previsão')));
}
