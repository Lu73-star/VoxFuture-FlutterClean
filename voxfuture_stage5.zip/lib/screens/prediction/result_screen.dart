import 'package:flutter/material.dart';
class ResultScreen extends StatelessWidget{
 static const routeName='/result';
 const ResultScreen({super.key});
 @override Widget build(c)=>Scaffold(body:Center(child:Text('Resultado')));
}
