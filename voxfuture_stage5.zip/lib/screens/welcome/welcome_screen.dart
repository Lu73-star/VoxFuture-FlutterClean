import 'package:flutter/material.dart';
class WelcomeScreen extends StatelessWidget{
 static const routeName='/welcome';
 const WelcomeScreen({super.key});
 @override Widget build(c)=>Scaffold(body:Center(child:Text('Welcome Ultra Sci-Fi')));
}
