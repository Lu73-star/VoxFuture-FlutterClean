class AIService{
 Future<String> generatePrediction(String input) async{
  return 'Previsão simulada';
 }
}
