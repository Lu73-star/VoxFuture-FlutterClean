
class AIService {
  Future<String> generatePrediction(String input) async {
    await Future.delayed(Duration(seconds: 2));
    return "Uma análise futurista equilibrada: $input — "
           "percepções combinando lógica e intuição surgirão aqui.";
  }
}
