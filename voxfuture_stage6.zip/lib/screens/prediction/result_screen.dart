
import 'package:flutter/material.dart';

class ResultScreen extends StatelessWidget{
  static const routeName='/result';
  const ResultScreen({super.key});
  @override
  Widget build(c){
    final String result = ModalRoute.of(c)!.settings.arguments as String;
    return Scaffold(
      appBar: AppBar(title: Text("Resultado")),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Text(result, style: TextStyle(fontSize:18)),
      ),
    );
  }
}
