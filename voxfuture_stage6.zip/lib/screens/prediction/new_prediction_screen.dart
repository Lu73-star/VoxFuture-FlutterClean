
import 'package:flutter/material.dart';
import '../../services/ai_service.dart';
import 'result_screen.dart';

class NewPredictionScreen extends StatefulWidget {
  static const routeName = '/new_prediction';
  const NewPredictionScreen({super.key});
  @override
  State<NewPredictionScreen> createState() => _NewPredictionScreenState();
}

class _NewPredictionScreenState extends State<NewPredictionScreen>{
  final _controller = TextEditingController();
  bool loading=false;

  void _submit() async {
    setState(()=>loading=true);
    final text=_controller.text;
    final res=await AIService().generatePrediction(text);
    if(!mounted)return;
    setState(()=>loading=false);
    Navigator.pushNamed(context, ResultScreen.routeName, arguments: res);
  }

  @override
  Widget build(c){
    return Scaffold(
      appBar: AppBar(title: Text("Nova Previsão")),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          children:[
            TextField(
              controller:_controller,
              decoration: InputDecoration(hintText:"Digite sua pergunta..."),
            ),
            SizedBox(height:20),
            loading?CircularProgressIndicator():
            ElevatedButton(onPressed:_submit, child: Text("Gerar")),
          ],
        ),
      ),
    );
  }
}
