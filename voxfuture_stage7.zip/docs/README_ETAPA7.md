
# VoxFuture - Etapa 7 (Integração OpenAI)

Esta etapa adiciona integração real com a API da OpenAI.

## Arquivos principais

- `lib/services/ai_service.dart`
- `lib/screens/prediction/new_prediction_screen.dart`
- `lib/screens/prediction/result_screen.dart`

## Como configurar a chave no Replit

1. No Replit, abra o projeto VoxFuture.
2. Vá em **Secrets** (ícone de cadeado).
3. Crie uma nova chave:
   - KEY: `OPENAI_API_KEY`
   - VALUE: `sua-chave-aqui`
4. Salve.

## Observação

A chave **não** deve ser colocada no código nem no GitHub.
