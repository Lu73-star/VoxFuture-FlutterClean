
import 'dart:convert';
import 'package:http/http.dart' as http;

/// Serviço de IA do VoxFuture.
/// Usa a chave OPENAI_API_KEY configurada no ambiente (Replit Secrets).
class AIService {
  static const _endpoint = 'https://api.openai.com/v1/chat/completions';
  static const _model = 'gpt-4.1-mini';

  /// Gera uma previsão em estilo futurista híbrido (Estilo C).
  Future<String> generatePrediction(String question) async {
    if (question.trim().isEmpty) {
      return 'Para que eu possa te ajudar, descreva com algumas palavras o cenário ou decisão que você está analisando.';
    }

    final apiKey = const String.fromEnvironment('OPENAI_API_KEY');
    if (apiKey.isEmpty) {
      return 'A IA do VoxFuture ainda não foi ativada com uma chave de acesso. '
          'Configure a variável OPENAI_API_KEY no ambiente seguro para liberar as previsões reais.';
    }

    try {
      final uri = Uri.parse(_endpoint);
      final headers = <String, String>{
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $apiKey',
      };

      final body = jsonEncode({
        'model': _model,
        'messages': [
          {
            'role': 'system',
            'content':
                'Você é a VoxFuture, uma IA de previsões em estilo futurista híbrido: '
                'profunda, lógica, sensível e sóbria. Você não adivinha, '
                'mas analisa cenários, riscos, tendências e caminhos possíveis. '
                'Fale em português, em tom acolhedor, objetivo e elegante.'
          },
          {
            'role': 'user',
            'content':
                'Cenário do usuário (responda como VoxFuture, em até 3 parágrafos):\n$question'
          }
        ],
        'max_tokens': 450,
        'temperature': 0.65,
      });

      final response = await http.post(uri, headers: headers, body: body);

      if (response.statusCode != 200) {
        return 'Encontrei um problema ao acessar a IA agora (código ${response.statusCode}). '
            'Tente novamente em alguns instantes.';
      }

      final data = jsonDecode(response.body) as Map<String, dynamic>;
      final choices = data['choices'] as List<dynamic>?;
      if (choices == null || choices.isEmpty) {
        return 'Não consegui formular uma resposta útil neste momento. '
            'Tente reformular a pergunta com mais detalhes.';
      }

      final msg = choices.first['message'];
      final content = msg != null ? msg['content'] as String? : null;
      if (content == null || content.trim().isEmpty) {
        return 'Recebi uma resposta vazia da IA. Tente novamente com uma pergunta um pouco mais específica.';
      }

      return content.trim();
    } catch (e) {
      return 'Houve uma falha de comunicação com a IA do VoxFuture. '
          'Verifique sua conexão e a configuração da chave, depois tente novamente.';
    }
  }
}
