
import 'package:flutter/material.dart';

class ResultScreen extends StatelessWidget {
  static const routeName = '/result';
  const ResultScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final String result =
        ModalRoute.of(context)!.settings.arguments as String? ??
            'Nenhuma previsão disponível. Tente novamente.';

    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Leitura VoxFuture'),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            children: [
              Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(
                    color: const Color(0xFFF3A622).withOpacity(0.6),
                  ),
                  gradient: const LinearGradient(
                    colors: [
                      Color(0xFF0B0914),
                      Color(0xFF141020),
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFFF3A622).withOpacity(0.25),
                      blurRadius: 20,
                      offset: const Offset(0, 6),
                    ),
                  ],
                ),
                child: SingleChildScrollView(
                  child: Text(
                    result,
                    style: theme.textTheme.bodyMedium?.copyWith(
                      height: 1.4,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 24),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () {
                        Navigator.popUntil(
                          context,
                          (route) => route.settings.name == '/',
                        );
                      },
                      child: const Text('Voltar ao início'),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.popUntil(
                          context,
                          (route) =>
                              route.settings.name == '/' ||
                              route.settings.name == '/home',
                        );
                        Navigator.pushNamed(context, '/new_prediction');
                      },
                      child: const Text('Nova previsão'),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
