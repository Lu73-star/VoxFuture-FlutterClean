
import 'package:flutter/material.dart';
import '../../services/ai_service.dart';
import 'result_screen.dart';

class NewPredictionScreen extends StatefulWidget {
  static const routeName = '/new_prediction';
  const NewPredictionScreen({super.key});

  @override
  State<NewPredictionScreen> createState() => _NewPredictionScreenState();
}

class _NewPredictionScreenState extends State<NewPredictionScreen>
    with SingleTickerProviderStateMixin {
  final _controller = TextEditingController();
  final _aiService = AIService();
  bool _loading = false;

  late AnimationController _pulseController;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      lowerBound: 0.9,
      upperBound: 1.1,
      duration: const Duration(milliseconds: 900),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _controller.dispose();
    _pulseController.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    final text = _controller.text.trim();
    if (text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Descreva ao menos um pouco o cenário.')),
      );
      return;
    }

    setState(() => _loading = true);
    try {
      final prediction = await _aiService.generatePrediction(text);
      if (!mounted) return;
      Navigator.pushNamed(
        context,
        ResultScreen.routeName,
        arguments: prediction,
      );
    } finally {
      if (mounted) {
        setState(() => _loading = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Nova previsão'),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            children: [
              Text(
                'Sobre o que você quer clareza?',
                style: theme.textTheme.titleMedium,
              ),
              const SizedBox(height: 12),
              Text(
                'Explique em poucas linhas o cenário, dúvida ou decisão. '
                'A VoxFuture vai analisar e devolver uma leitura equilibrada do momento.',
                style: theme.textTheme.bodySmall,
              ),
              const SizedBox(height: 24),
              Expanded(
                child: TextField(
                  controller: _controller,
                  maxLines: null,
                  expands: true,
                  textInputAction: TextInputAction.newline,
                  decoration: const InputDecoration(
                    hintText:
                        'Ex: Estou pensando em mudar de trabalho nos próximos meses, '
                        'mas não sei se é o momento certo...',
                    alignLabelWithHint: true,
                  ),
                ),
              ),
              const SizedBox(height: 24),
              GestureDetector(
                onTap: _loading ? null : _submit,
                child: ScaleTransition(
                  scale: _loading ? _pulseController : const AlwaysStoppedAnimation(1.0),
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(32),
                      gradient: const LinearGradient(
                        colors: [
                          Color(0xFFF3A622),
                          Color(0xFFFFD67A),
                        ],
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: const Color(0xFFF3A622).withOpacity(0.4),
                          blurRadius: 18,
                          spreadRadius: 1,
                          offset: const Offset(0, 4),
                        ),
                      ],
                    ),
                    child: Center(
                      child: _loading
                          ? Row(
                              mainAxisSize: MainAxisSize.min,
                              children: const [
                                SizedBox(
                                  width: 18,
                                  height: 18,
                                  child: CircularProgressIndicator(
                                    strokeWidth: 2,
                                    valueColor: AlwaysStoppedAnimation<Color>(
                                      Color(0xFF2A1A05),
                                    ),
                                  ),
                                ),
                                SizedBox(width: 10),
                                Text(
                                  'Analisando cenário...',
                                  style: TextStyle(
                                    color: Color(0xFF2A1A05),
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ],
                            )
                          : const Text(
                              'Gerar previsão',
                              style: TextStyle(
                                color: Color(0xFF2A1A05),
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'VoxFuture não adivinha: ela analisa tendências, riscos e possibilidades.',
                style: theme.textTheme.bodySmall?.copyWith(fontSize: 11),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
